const canvas = document.getElementById("jogoCanva");
const ctx = canvas.getContext("2d");
const player = {
  x: 50,
  y: 400,
  width: 32,
  height: 32,
  frameAtual: 0,
  frameMax: 4,
  linhaAnimacao: 0,
  contadorFrames: 0,
  frameDelay: 8,
  color: "white",
  velocidadeX: 0,
  velocidadeY: 0,
  noChao: true,
  estado: "idle",
};
player.larguraSprite = 64; // ou o tamanho real do sprite que você quer
player.alturaSprite = 64;

const spritePersonagem = new Image();
spritePersonagem.src = "knight.png";
const spriteLargura = 32;
const spriteAltura = 32;
const estadosAnimacao = {
  idle: 0,
  run: 1,
};
// Atualizar estado do player com base nas teclas pressionadas
function atualizarEstado() {
  if (teclas["d"] || teclas["a"]) {
    player.estado = "run";
    player.frameMax = 4;
  } else {
    player.estado = "idle"; // Parado
    player.frameMax = 1;
    player.linhaAnimacao = estadosAnimacao[player.estado];
  }
}
const teclas = {};
document.addEventListener("keydown", (evento) => {
  teclas[evento.key] = true;
});
document.addEventListener("keyup", (evento) => {
  teclas[evento.key] = false;
});

player.coyoteTime = 0;

//atualiza quando algo acontece, quando o jogador se move, quando pisa em uma plataforma, etc
function atualizar() {
  const gravidade = 0.2;
  const forcaDoPulo = -7;

  player.velocidadeY += gravidade;
  let proximoY = player.y + player.velocidadeY;
  let proximoX = player.x + player.velocidadeX;

  let colidiu_plataformaY = false;
  let colidiuPlataformax = false;

  // verifica se vai colidir com alguma plataforma
  for (const p of plataformas) {
    const margem = 3;
    const encostandoPorCima =
      player.y + player.height <= p.y &&
      proximoY + player.height >= p.y &&
      player.x + player.width > p.x + 1 &&
      player.x < p.x + p.width - 1;

    if (encostandoPorCima) {
      player.y = p.y - player.height; // fica em cima a plataforma
      player.velocidadeY = 0;
      player.noChao = true;
      colidiu_plataformaY = true;
      break;
    }
    const encostandoPorBaixo =
      player.y >= p.y + p.height &&
      proximoY <= p.y + p.height &&
      player.x + player.width > p.x &&
      player.x < p.x + p.width;
    if (encostandoPorBaixo) {
      player.y = p.y + p.height;
      player.velocidadeY = 0;
    }
  }
  for (const p of plataformas) {
    const pelaDireita =
      player.x <= p.x + p.width &&
      player.x >= p.x + p.width - 10 &&
      player.y + player.height > p.y &&
      player.y < p.y + p.height;

    if (pelaDireita && player.velocidadeX < 0) {
      player.x = p.x + p.width;
      proximoX = p.x + p.width;
    }
    const pelaEsquerda =
      player.x + player.width >= p.x &&
      player.x + player.width <= p.x + 10 &&
      player.y + player.height > p.y &&
      player.y < p.y + p.height;

    if (pelaEsquerda && player.velocidadeX > 0) {
      player.x = p.x - player.width;
    }
  }
  // se não colidir, aplica o movimento de queda
  if (!colidiu_plataformaY) {
    player.y = proximoY;
    player.noChao = false;
    if (player.coyoteTime > 0) player.coyoteTime--;
  } else {
    player.noChao = true;
    player.coyoteTime = 10;
  }

  // verifica se chegou no chão do canvas
  if (player.y + player.height >= 500) {
    player.y = 500 - player.height;
    player.noChao = true;
    player.coyoteTime = 10;
  }

  // movimento horizontal (esquerda/direita)
  player.x += player.velocidadeX;
  if (teclas["d"]) {
    player.velocidadeX = 2;
    player.direcao = "direita";
  } else if (teclas["a"]) {
    player.velocidadeX = -2;
    player.direcao = "esquerda";
  } else {
    player.velocidadeX = 0;
  }

  if (teclas["w"] && player.coyoteTime > 0) {
    player.velocidadeY = Math.min(
      player.velocidadeY + forcaDoPulo,
      forcaDoPulo
    );
    player.coyoteTime = 0; // usou o tempo de pulo
  }

  // limites do canvas para o player não sair da tela
  if (player.x < 0) player.x = 0;
  if (player.x + player.width > canvas.width)
    player.x = canvas.width - player.width;
}
//criando as plataformas //////////////////////////////////////////////////////////////////////
const plataformas = [
  { x: 0, y: 480, width: 1000, height: 60, tipo: "grama" },
  { x: 300, y: 400, width: 100, height: 25, tipo: "grama" },
  { x: 340, y: 400, width: 25, height: 100, tipo: "grama" },
  { x: 300, y: 200, width: 100, height: 25, tipo: "grama" },
  { x: 0, y: 300, width: 200, height: 25, tipo: "grama" },
];

function desenharPlayer() {
  ctx.save();
  if (player.direcao === "esquerda") {
    ctx.translate(player.x + player.width / 2, 0);
    ctx.scale(-1, 1);
    ctx.translate(-(player.x + player.width / 2), 0);
  }
  ctx.fillStyle = player.color;
  player.contadorFrames++;
  if (player.contadorFrames >= player.frameDelay) {
    player.frameAtual = (player.frameAtual + 1) % player.frameMax;
    player.contadorFrames = 0;
  }
  const ajusteY = -9;
  const centroX = player.x + player.width / 2;
  const centroY = player.y + player.height / 2;

  const spriteX = centroX - player.larguraSprite / 2;
  const spriteY = centroY - player.alturaSprite / 2 + ajusteY;
  ctx.drawImage(
    spritePersonagem,
    player.frameAtual * spriteLargura,
    player.linhaAnimacao * spriteAltura,
    spriteLargura,
    spriteAltura,
    spriteX,
    spriteY,
    player.larguraSprite,
    player.alturaSprite
  );

  ctx.restore();
}
const background = new Image();
background.src = "Background.jpg";

function desenhar() {
  ctx.fillStyle = "#87CEEB";
  ctx.drawImage(background, 0, 0, canvas.width, canvas.height);
  desenharPlayer();
  desenhaPlataformas();
}
const texturaTerra = new Image();
texturaTerra.src = "terra.png";

const texturagrama = new Image();
texturagrama.src = "grama.avif";

function desenhaPlataformas() {
  for (const p of plataformas) {
    //o P  é um laço de repetição que server pra passar por cada plataforma da lista
    let textura;

    if (p.tipo === "terra") {
      textura = texturaTerra;
    } else if (p.tipo === "grama") {
      textura = texturagrama;
    } else {
      continue;
    }
    const pattern = ctx.createPattern(textura, "repeat");
    ctx.fillStyle = pattern;
    ctx.fillRect(p.x, p.y, p.width, p.height);
  }
}
function loopJogo() {
  atualizarEstado();
  atualizar();
  desenhar();
  requestAnimationFrame(loopJogo);
}
loopJogo();
