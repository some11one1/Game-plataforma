const canvas = document.getElementById("jogoCanva");
const ctx = canvas.getContext("2d");
let tempo = 20;
let intervaloTempo;
let gameOver = false;
let tempoIniciado = false;
const player = {
  x: 50,
  y: 400,
  width: 32,
  height: 32,
  frameAtual: 0,
  frameMax: 4,
  linhaAnimacao: 0,
  contadorFrames: 0,
  frameDelay: 8,
  color: "white",
  velocidadeX: 0,
  velocidadeY: 0,
  noChao: true,
  estado: "idle",
};
player.larguraSprite = 64; //  o tamanho real do sprite que você quer
player.alturaSprite = 64;

const spritePersonagem = new Image();
spritePersonagem.src = "knight.png";
const spriteLargura = 32;
const spriteAltura = 32;
const estadosAnimacao = {
  idle: 0,
  run: 1,
};
// Atualizar estado do player com base nas teclas pressionadas
function atualizarEstado() {
  if (teclas["d"] || teclas["a"]) {
    player.estado = "run";
    player.frameMax = 4;
  } else {
    player.estado = "idle"; // Parado
    player.frameMax = 1;
    player.linhaAnimacao = estadosAnimacao[player.estado];
  }
}
const teclas = {};
document.addEventListener("keydown", (evento) => {
  teclas[evento.key] = true;
});
document.addEventListener("keyup", (evento) => {
  teclas[evento.key] = false;
});

player.coyoteTime = 0;

//atualiza quando algo acontece, quando o jogador se move, quando pisa em uma plataforma, etc
function atualizar() {
  const gravidade = 0.2;
  const forcaDoPulo = -6.5;

  player.velocidadeY += gravidade;
  let proximoY = player.y + player.velocidadeY;
  let proximoX = player.x + player.velocidadeX;

  let colidiu_plataformaY = false;
  let colidiuPlataformax = false;

  // verifica se vai colidir com alguma plataforma
  for (const p of plataformas) {
    if (p.semColisao) continue;
    const margem = 3;
    const encostandoPorCima =
      player.y + player.height <= p.y &&
      proximoY + player.height >= p.y &&
      player.x + player.width > p.x + 1 &&
      player.x < p.x + p.width - 1;

    if (encostandoPorCima) {
      player.y = p.y - player.height; // fica em cima a plataforma
      player.velocidadeY = 0;
      player.noChao = true;
      colidiu_plataformaY = true;
      break;
    }
    const encostandoPorBaixo =
      player.y >= p.y + p.height &&
      proximoY <= p.y + p.height &&
      player.x + player.width > p.x &&
      player.x < p.x + p.width;
    if (encostandoPorBaixo) {
      player.y = p.y + p.height;
      player.velocidadeY = 0;
    }
  }
  for (const p of plataformas) {
    if (p.semColisao) continue;
    const pelaDireita =
      player.x <= p.x + p.width &&
      player.x >= p.x + p.width - 10 &&
      player.y + player.height > p.y &&
      player.y < p.y + p.height;

    if (pelaDireita && player.velocidadeX < 0) {
      player.x = p.x + p.width;
      proximoX = p.x + p.width;
    }
    const pelaEsquerda =
      player.x + player.width >= p.x &&
      player.x + player.width <= p.x + 10 &&
      player.y + player.height > p.y &&
      player.y < p.y + p.height;

    if (pelaEsquerda && player.velocidadeX > 0) {
      player.x = p.x - player.width;
    }
  }
  // se não colidir, aplica o movimento de queda
  if (!colidiu_plataformaY) {
    player.y = proximoY;
    player.noChao = false;
    if (player.coyoteTime > 0) player.coyoteTime--;
  } else {
    player.noChao = true;
    player.coyoteTime = 5;
  }

  // verifica se chegou no chão do canvas
  if (player.y + player.height >= 500) {
    player.y = 500 - player.height;
    player.noChao = true;
    player.coyoteTime = 5;
  }

  // movimento horizontal (esquerda/direita)
  player.x += player.velocidadeX;
  if (teclas["d"]) {
    player.velocidadeX = 4;
    player.direcao = "direita";
    ContagemTempo();
    tempoIniciado = true;
  } else if (teclas["a"]) {
    player.velocidadeX = -4;
    player.direcao = "esquerda";
    ContagemTempo();
    tempoIniciado = true;
  } else {
    player.velocidadeX = 0;
  }
  if (teclas[" "] && player.coyoteTime > 0) {
    player.velocidadeY = Math.min(
      player.velocidadeY + forcaDoPulo,
      forcaDoPulo
    );
    player.coyoteTime = 0; // usou o tempo de pulo
    ContagemTempo();
    tempoIniciado = true;
  }

  // limites do canvas para o player não sair da tela
  if (player.x < 0) player.x = 0;
  if (player.x + player.width > canvas.width)
    player.x = canvas.width - player.width;
}

//criando as plataformas //////////////////////////////////////////////////////////////////////
const plataformas = [
  { x: 0, y: 480, width: 1000, height: 60, tipo: "grama", fase: 0 },
  { x: 300, y: 400, width: 100, height: 25, tipo: "grama", fase: 0 },
  { x: 600, y: 300, width: 100, height: 25, tipo: "grama", fase: 0 },
  { x: 640, y: 325, width: 25, height: 155, tipo: "terra", fase: 0 , semColisao: true },
  { x: 640, y: 225, width: 25, height: 75, tipo: "terra", fase: 0 ,semColisao: true },
  { x: 600, y: 0, width: 25, height: 150, tipo: "terra",fase: 0 },
  { x: 620, y: 130, width: 95, height: 20, tipo: "terra", fase: 0},
  { x: 625, y: 115, width: 90, height: 15, tipo: "grama", fase: 0 },
  { x: 600, y: 200, width: 100, height: 25, tipo: "grama", fase: 0},
  { x: 850, y: 150, width: 150, height: 25, tipo: "grama",fase: 0 },
  { x: 850, y: 175, width: 150, height: 305, tipo: "terra",fase: 0 },
  { x: 300, y: 200, width: 100, height: 25, tipo: "grama",fase: 0 },
  { x: 340, y: 425, width: 25, height: 55, tipo: "terra", fase: 0, semColisao: true },
  { x: 340, y: 225, width: 25, height: 175, tipo: "terra",fase: 0, semColisao: true },
  { x: 0, y: 300, width: 200, height: 25, tipo: "grama",fase: 0 },

];

const espinhos = [
  { x: 145, y: 268, width: 32, height: 32, fase: 0},
  { x: 150, y: 448, width: 32, height: 32, fase: 0 },
  { x: 335, y: 169, width: 32, height: 32, fase: 0},
];
function desenharPlayer() {
  ctx.save();
  if (player.direcao === "esquerda") {
    ctx.translate(player.x + player.width / 2, 0);
    ctx.scale(-1, 1);
    ctx.translate(-(player.x + player.width / 2), 0);
  }
  ctx.fillStyle = player.color;
  player.contadorFrames++;
  if (player.contadorFrames >= player.frameDelay) {
    player.frameAtual = (player.frameAtual + 1) % player.frameMax;
    player.contadorFrames = 0;
  }
  const ajusteY = -9;
  const centroX = player.x + player.width / 2;
  const centroY = player.y + player.height / 2;

  const spriteX = centroX - player.larguraSprite / 2;
  const spriteY = centroY - player.alturaSprite / 2 + ajusteY;
  ctx.drawImage(
    spritePersonagem,
    player.frameAtual * spriteLargura,
    player.linhaAnimacao * spriteAltura,
    spriteLargura,
    spriteAltura,
    spriteX,
    spriteY,
    player.larguraSprite,
    player.alturaSprite
  );

  ctx.restore();
}
const background = new Image();
background.src = "Background.jpg";

function desenhar() {
   
  ctx.fillStyle = "#87CEEB";
  ctx.drawImage(background, 0, 0, canvas.width, canvas.height);
  desenharPlayer();
  desenhaPlataformas(faseatual());
  desenharEspinho(faseatual());
}

const faseatual = function() {

  // Mudar de fase
  return 0;
}
const texturaTerra = new Image();
texturaTerra.src = "terra.jpg";

const texturagrama = new Image();
texturagrama.src = "grama.avif";

function desenhaPlataformas(faseAtual) {
  for (const p of plataformas) {
    //o P  é um laço de repetição que server pra passar por cada plataforma da lista
    let textura;
   if (p.fase === faseAtual) {
    if (p.tipo === "terra") {
      textura = texturaTerra;
    } else if (p.tipo === "grama") {
      textura = texturagrama;
    } else {
      continue;
    }
    const pattern = ctx.createPattern(textura, "repeat");
    ctx.fillStyle = pattern;
    ctx.fillRect(p.x, p.y, p.width, p.height);
  }
}
}
const spriteEspinho = new Image();
spriteEspinho.src = "espinho.png"; // nome da sua imagem de espinho

function desenharEspinho(faseAtual) {
  for (const e of espinhos)
    if (e.fase === faseAtual)
    ctx.drawImage(spriteEspinho, 0, 0, 16, 16, e.x, e.y, e.width, e.height);
}

function verificarColisaoEspinho() {
  for (const e of espinhos) {
    const tocouEspinho =
      player.x < e.x + e.width &&
      player.x + player.width > e.x &&
      player.y < e.y + e.height &&
      player.y + player.height > e.y;

    if (tocouEspinho) {
      location.reload();
    }
  }
}
function loopJogo() {
  atualizarEstado();
  atualizar();
  desenhar();
  verificarColisaoEspinho();
  requestAnimationFrame(loopJogo);
}
function ContagemTempo() {
  if (tempoIniciado) return;
  tempoIniciado = true;
  intervaloTempo = setInterval(() => {
    if (!gameOver) {
      tempo--;
      if (tempo <= 0) {
        gameOver = true;
        alert("acabou o Tempo");
        location.reload();
      }
    }
    document.getElementById("tempoTela").textContent = `Tempo: ${tempo}s`;
  }, 1000);
}
loopJogo();
