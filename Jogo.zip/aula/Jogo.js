const canvas = document.getElementById("jogoCanva");
const ctx = canvas.getContext("2d");
const player = {
  x: 50,
  y: 465,
  width: 30,
  height: 30,
  color: "white",
  velocidadeX: 0,
  velocidadeY: 0,
};
const teclas = {};
document.addEventListener("keyDown", (evento) => {
  teclas[evento.key] = true;
});
document.addEventListener("keydown", (evento) => {
  teclas[evento.key] = false;
});
function atualizar() {
  // movimento esquerda e direita
  if (teclas["d"]) {
    player.velocidadeX = 5;
  } else if (teclas["a"]) {
    player.velocidadeX = -5;
  } else {
    player.velocidadeX = 0;
  }
}

function desenharPlayer() {
  ctx.fillStyle = player.color;
  ctx.fillRect(player.x, player.y, player.width, player.height);
}
function desenhar() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  desenharPlayer();
}
function loopJogo() {
  desenhar();
  requestAnimationFrame(loopJogo);
}
loopJogo();
