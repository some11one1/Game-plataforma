const canvas = document.getElementById("jogoCanva");
const ctx = canvas.getContext("2d");
let tempo = 200;
let intervaloTempo;
let gameOver = false;
let tempoIniciado = false;
let playerMorreu = false;

const musica = new Audio("musica1.mp3");
musica.loop = true;
musica.volume = 0.5;
musica.play().catch((e) => {
  console.log("testanto");
});

const player = {
  x: 50,
  y: 400,
  width: 32,
  height: 32,
  frameAtual: 0,
  frameMax: 4,
  linhaAnimacao: 0,
  contadorFrames: 0,
  frameDelay: 8,
  color: "white",
  velocidadeX: 0,
  velocidadeY: 0,
  noChao: true,
  estado: "idle",
  encostandoParedeEsquerda: false,
  encostandoParedeDireita: false,
  ultimaParedeWallJump: null,
  wallJumpTempo: 0,
};
player.larguraSprite = 64; //  o tamanho real
player.alturaSprite = 64;

const spritePersonagem = new Image();
spritePersonagem.src = "knight.png";
const spriteLargura = 32;
const spriteAltura = 32;
const estadosAnimacao = {
  idle: 0,
  run: 1,
};
// Atualizar estado do player com base nas teclas pressionadas
function atualizarEstado() {
  if (teclas["d"] || teclas["a"]) {
    player.estado = "run";
    player.frameMax = 4;
  } else {
    player.estado = "idle"; // Parado
    player.frameMax = 1;
    player.linhaAnimacao = estadosAnimacao[player.estado];
  }
}
const teclas = {};
document.addEventListener("keydown", (evento) => {
  if (!teclas[evento.key]) {
    teclas[evento.key] = true;

    if (evento.key === " ") {
      if (player.coyoteTime > 0) {
        player.velocidadeY = forcaDoPulo;
        player.coyoteTime = 0;
        player.ultimaParedeWallJump = null;
      } else if (
        !player.noChao &&
        (player.encostandoParedeDireita || player.encostandoParedeEsquerda)
      ) {
        if (
          player.encostandoParedeDireita &&
          player.ultimaParedeWallJump !== "direita"
        ) {
          player.velocidadeY = forcaDoPulo;
          player.ultimaParedeWallJump = "direita";
        } else if (
          player.encostandoParedeEsquerda &&
          player.ultimaParedeWallJump !== "esquerda"
        ) {
          player.velocidadeY = forcaDoPulo;
          player.ultimaParedeWallJump = "esquerda";
        }
      }
    }
  }
});
// adicionando um evento para verificar se o jogador pode pular
document.addEventListener("keyup", (evento) => {
  teclas[evento.key] = false;
  if (evento.key === " ") {
    musica.play();
    podePular = true;
  }
});

player.coyoteTime = 0;

let podePular = true;
const forcaDoPulo = -14;

//atualiza quando algo acontece, quando o jogador se move, quando pisa em uma plataforma, etc
function atualizar() {
  player.encostandoParedeDireita = false;
  player.encostandoParedeEsquerda = false;

  const gravidade = 0.8;

  player.velocidadeY += gravidade;
  let proximoY = player.y + player.velocidadeY;
  let proximoX = player.x + player.velocidadeX;

  let colidiu_plataformaY = false;
  let colidiuPlataformax = false;

  // verifica se vai colidir com alguma plataforma
  for (const p of plataformasDaFase(faseatual())) {
    if (p.semColisao) continue;
    const margem = 3;
    const encostandoPorCima =
      player.y + player.height <= p.y &&
      proximoY + player.height >= p.y &&
      player.x + player.width > p.x + 1 &&
      player.x < p.x + p.width - 1;

    if (encostandoPorCima) {
      player.y = p.y - player.height; // fica em cima a plataforma
      player.velocidadeY = 0;
      player.noChao = true;
      colidiu_plataformaY = true;
      break;
    }
    const encostandoPorBaixo =
      player.y >= p.y + p.height &&
      proximoY <= p.y + p.height &&
      player.x + player.width > p.x &&
      player.x < p.x + p.width;
    if (encostandoPorBaixo) {
      player.y = p.y + p.height;
      player.velocidadeY = 0;
    }
  }
  for (const p of plataformasDaFase(faseatual())) {
    if (p.semColisao) continue;
    const pelaDireita =
      player.x <= p.x + p.width &&
      player.x >= p.x + p.width - 10 &&
      player.y + player.height > p.y &&
      player.y < p.y + p.height;

    if (pelaDireita && player.velocidadeX < 0) {
      player.x = p.x + p.width;
      proximoX = p.x + p.width;
      player.encostandoParedeEsquerda = true;
    }
    const pelaEsquerda =
      player.x + player.width >= p.x &&
      player.x + player.width <= p.x + 10 &&
      player.y + player.height > p.y &&
      player.y < p.y + p.height;

    if (pelaEsquerda && player.velocidadeX > 0) {
      player.x = p.x - player.width;
      player.encostandoParedeDireita = true;
    }
  }
  // se não colidir, aplica o movimento de queda
  if (!colidiu_plataformaY) {
    player.y = proximoY;
    player.noChao = false;
    if (player.coyoteTime > 0) player.coyoteTime--;
  } else {
    player.noChao = true;
    player.coyoteTime = 5;
  }

  // verifica se chegou no chão do canvas
  if (player.y + player.height >= 500) {
    player.y = 500 - player.height;
    player.noChao = true;
    player.coyoteTime = 5;
    player.ultimaParedeWallJump = null;
  }

  // movimento horizontal (esquerda/direita)
  player.x += player.velocidadeX;
  if (teclas["d"]) {
    player.velocidadeX = 4;
    player.direcao = "direita";
    ContagemTempo();
    tempoIniciado = true;
  } else if (teclas["a"]) {
    player.velocidadeX = -4;
    player.direcao = "esquerda";
    ContagemTempo();
    tempoIniciado = true;
  } else {
    player.velocidadeX = 0;
  }
  // limites do canvas para o player não sair da tela
  if (player.x < 0) player.x = 0;
  if (player.x + player.width > canvas.width)
    player.x = canvas.width - player.width;
}

//criando as plataformas //////////////////////////////////////////////////////////////////////
const plataformas = [
  { x: 0, y: 480, width: 1000, height: 20, tipo: "terra", fase: 0 },
  { x: 174, y: 431, width: 100, height: 50, tipo: "terra", fase: 0 },
  { x: 274, y: 381, width: 100, height: 100, tipo: "terra", fase: 0 },
  { x: 348, y: 131, width: 27, height: 250, tipo: "terra", fase: 0 },
  { x: 0, y: 250, width: 225, height: 25, tipo: "terra", fase: 0 },
  { x: 0, y: 140, width: 25, height: 25, tipo: "terra", fase: 0 },
  { x: 170, y: 80, width: 125, height: 25, tipo: "terra", fase: 0 },
  { x: 460, y: 0, width: 28, height: 250, tipo: "terra", fase: 0 },
  { x: 467, y: 330, width: 25, height: 150, tipo: "terra", fase: 0 },
  { x: 589, y: 140, width: 100, height: 25, tipo: "terra", fase: 0 },
  { x: 772, y: 181, width: 25, height: 300, tipo: "terra", fase: 0 },
  { x: 904, y: 355, width: 100, height: 125, tipo: "terra", fase: 0 },
  { x: 904, y: 0, width: 25, height: 275, tipo: "terra", fase: 0 },
  { x: 855, y: 0, width: 50, height: 125, tipo: "terra", fase: 0 },

  { x: 0, y: 465, width: 175, height: 15, tipo: "grama", fase: 0 },
  { x: 174, y: 415, width: 100, height: 15, tipo: "grama", fase: 0 },
  { x: 274, y: 367, width: 75, height: 15, tipo: "grama", fase: 0 },
  { x: 0, y: 235, width: 226, height: 15, tipo: "grama", fase: 0 },
  { x: 0, y: 125, width: 26, height: 15, tipo: "grama", fase: 0 },
  { x: 467, y: 316, width: 26, height: 15, tipo: "grama", fase: 0 },
  { x: 348, y: 117, width: 26, height: 15, tipo: "grama", fase: 0 },
  { x: 772, y: 167, width: 26, height: 15, tipo: "grama", fase: 0 },
  { x: 168, y: 65, width: 127, height: 15, tipo: "grama", fase: 0 },
  { x: 589, y: 125, width: 100, height: 15, tipo: "grama", fase: 0 },
  { x: 904, y: 340, width: 100, height: 15, tipo: "grama", fase: 0 },
  { x: 374, y: 465, width: 530, height: 15, tipo: "grama", fase: 0 },

  //fase 2
  { x: 0, y: 480, width: 1000, height: 20, tipo: "terra", fase: 1 },
  { x: 0, y: 460, width: 710, height: 20, tipo: "grama", fase: 1 },
  { x: 140, y: 110, width: 25, height: 350, tipo: "terra", fase: 1 },
  { x: 0, y: 110, width: 25, height: 350, tipo: "terra", fase: 1 },
  { x: 268, y: 310, width: 100, height: 150, tipo: "terra", fase: 1 },
  { x: 268, y: 295, width: 100, height: 15, tipo: "grama", fase: 1 },
  { x: 530, y: 310, width: 25, height: 150, tipo: "terra", fase: 1 },
  { x: 530, y: 100, width: 25, height: 150, tipo: "terra", fase: 1 },
  { x: 710, y: 130, width: 290, height: 350, tipo: "terra", fase: 1 },
  { x: 710, y: 125, width: 290, height: 15, tipo: "grama", fase: 1 },
];

const espinhos = [
  { x: 348, y: 91, width: 25, height: 25, fase: 0 },
  { x: 374, y: 440, width: 25, height: 25, fase: 0 },
  { x: 401, y: 440, width: 25, height: 25, fase: 0 },
  { x: 424, y: 440, width: 25, height: 25, fase: 0 },
  { x: 305, y: 270, width: 25, height: 25, fase: 1 },
  { x: 443, y: 440, width: 25, height: 25, fase: 0 },
  { x: 491, y: 440, width: 25, height: 25, fase: 0 },
  { x: 517, y: 440, width: 25, height: 25, fase: 0 },
  { x: 543, y: 440, width: 25, height: 25, fase: 0 },
  { x: 568, y: 440, width: 25, height: 25, fase: 0 },
  { x: 596, y: 440, width: 25, height: 25, fase: 0 },
  { x: 622, y: 440, width: 25, height: 25, fase: 0 },
  { x: 647, y: 440, width: 25, height: 25, fase: 0 },
  { x: 672, y: 440, width: 25, height: 25, fase: 0 },
  { x: 695, y: 440, width: 25, height: 25, fase: 0 },
  { x: 718, y: 440, width: 25, height: 25, fase: 0 },
  { x: 742, y: 440, width: 25, height: 25, fase: 0 },
  { x: 797, y: 440, width: 25, height: 25, fase: 0 },
  { x: 821, y: 440, width: 25, height: 25, fase: 0 },
  { x: 847, y: 440, width: 25, height: 25, fase: 0 },
  { x: 872, y: 440, width: 25, height: 25, fase: 0 },
  { x: 175, y: 391, width: 25, height: 25, fase: 0 },
  { x: 167, y: 210, width: 25, height: 25, fase: 0 },
  { x: 324, y: 341, width: 25, height: 25, fase: 0 },
  { x: 49, y: 210, width: 25, height: 25, fase: 0 },
  { x: 219, y: 42, width: 25, height: 25, fase: 0 },
  { x: 772, y: 142, width: 25, height: 25, fase: 0 },

  //fase 2
  { x: 0, y: 86, width: 25, height: 25, fase: 1 },
  { x: 165, y: 435, width: 25, height: 25, fase: 1 },
  { x: 190, y: 435, width: 25, height: 25, fase: 1 },
  { x: 215, y: 435, width: 25, height: 25, fase: 1 },
  { x: 240, y: 435, width: 25, height: 25, fase: 1 },
  { x: 370, y: 435, width: 25, height: 25, fase: 1 },
  { x: 395, y: 435, width: 25, height: 25, fase: 1 },
  { x: 420, y: 435, width: 25, height: 25, fase: 1 },
  { x: 445, y: 435, width: 25, height: 25, fase: 1 },
  { x: 470, y: 435, width: 25, height: 25, fase: 1 },
  { x: 495, y: 435, width: 25, height: 25, fase: 1 },
  { x: 555, y: 435, width: 25, height: 25, fase: 1 },
  { x: 580, y: 435, width: 25, height: 25, fase: 1 },
  { x: 605, y: 435, width: 25, height: 25, fase: 1 },
  { x: 630, y: 435, width: 25, height: 25, fase: 1 },
  { x: 655, y: 435, width: 25, height: 25, fase: 1 },
  { x: 680, y: 435, width: 25, height: 25, fase: 1 },
  { x: 750, y: 100, width: 25, height: 25, fase: 1 },
  { x: 775, y: 100, width: 25, height: 25, fase: 1 },
  { x: 800, y: 100, width: 25, height: 25, fase: 1 },
  { x: 865, y: 100, width: 25, height: 25, fase: 1 },
];
const bandeira = [
  { x: 950, y: 270, width: 75, height: 75, fase: 0 },
  { x: 950, y: 55, width: 75, height: 75, fase: 1 },
];
let bandeiraFrame = 0; // qual esta no momento
let bandeiraTempo = 0; // quanto tempo para mudar o frame
const bandeiraMaxFrames = 5; // total de frames
const bandeiraFrameDelay = 15; // delay para trocar de frame

function bandeiraDaFase(fase) {
  return bandeira.filter((b) => b.fase === fase);
}
const spriteBandeira = new Image();
spriteBandeira.src = "bandeira.png";

function desenharBandeira(faseAtual) {
  bandeiraTempo++;
  if (bandeiraTempo > bandeiraFrameDelay) {
    bandeiraTempo = 0;
    bandeiraFrame++;
    if (bandeiraFrame >= bandeiraMaxFrames) {
      bandeiraFrame = 0;
    }
  }
  const sx = bandeiraFrame * 60;

  for (const b of bandeiraDaFase(faseAtual))
    if (b.fase === faseAtual)
      ctx.drawImage(spriteBandeira, sx, 0, 60, 60, b.x, b.y, b.width, b.height);
}
function verificarToqueBandeira() {
  for (const b of bandeiraDaFase(faseatual())) {
    const tocouBandeira =
      player.x < b.x + b.width &&
      player.x + player.width > b.x &&
      player.y < b.y + b.height &&
      player.y + player.height > b.y;

    if (tocouBandeira) {
      faseAgora++;
      player.x = 50;
      player.y = 400;
      break;
    }
  }
}

function plataformasDaFase(fase) {
  return plataformas.filter((p) => p.fase === fase);
}
function espinhosDaFase(fase) {
  return espinhos.filter((e) => e.fase === fase);
}
function desenharPlayer() {
  ctx.save();
  if (player.direcao === "esquerda") {
    ctx.translate(player.x + player.width / 2, 0);
    ctx.scale(-1, 1);
    ctx.translate(-(player.x + player.width / 2), 0);
  }
  ctx.fillStyle = player.color;
  player.contadorFrames++;
  if (player.contadorFrames >= player.frameDelay) {
    player.frameAtual = (player.frameAtual + 1) % player.frameMax;
    player.contadorFrames = 0;
  }
  const ajusteY = -9;
  const centroX = player.x + player.width / 2;
  const centroY = player.y + player.height / 2;

  const spriteX = centroX - player.larguraSprite / 2;
  const spriteY = centroY - player.alturaSprite / 2 + ajusteY;
  ctx.drawImage(
    spritePersonagem,
    player.frameAtual * spriteLargura,
    player.linhaAnimacao * spriteAltura,
    spriteLargura,
    spriteAltura,
    spriteX,
    spriteY,
    player.larguraSprite,
    player.alturaSprite
  );

  ctx.restore();
}
const background = new Image();
background.src = "Background.jpg";

function desenhar() {
  ctx.fillStyle = "#87CEEB";
  ctx.drawImage(background, 0, 0, canvas.width, canvas.height);
  desenharPlayer();
  desenhaPlataformas(faseatual());
  desenharEspinho(faseatual());
  desenharBandeira(faseatual());
}

let faseAgora = 0;
const faseatual = function () {
  // Mudar de fase
  return faseAgora;
};

const texturaTerra = new Image();
texturaTerra.src = "terra.jpg";

const texturagrama = new Image();
texturagrama.src = "grama.avif";

function desenhaPlataformas(faseAtual) {
  for (const p of plataformas) {
    //o P  é um laço de repetição que server pra passar por cada plataforma da lista
    let textura;
    if (p.fase === faseAtual) {
      if (p.tipo === "terra") {
        textura = texturaTerra;
      } else if (p.tipo === "grama") {
        textura = texturagrama;
      } else {
        continue;
      }
      const pattern = ctx.createPattern(textura, "repeat");
      ctx.fillStyle = pattern;
      ctx.fillRect(p.x, p.y, p.width, p.height);
    }
  }
}
const spriteEspinho = new Image();
spriteEspinho.src = "espinho.png"; // nome da sua imagem de espinho

function desenharEspinho(faseAtual) {
  for (const e of espinhosDaFase(faseAtual))
    if (e.fase === faseAtual)
      ctx.drawImage(spriteEspinho, 0, 0, 16, 16, e.x, e.y, e.width, e.height);
}

function verificarColisaoEspinho() {
  if (playerMorreu) return;

  for (const e of espinhosDaFase(faseatual())) {
    const tocouEspinho =
      player.x < e.x + e.width &&
      player.x + player.width > e.x &&
      player.y < e.y + e.height &&
      player.y + player.height > e.y;

    if (tocouEspinho) {
      playerMorreu = false;
      player.x = 50;
      player.y = 400;
      break;
    }
  }
}

function loopJogo() {
  atualizarEstado();
  atualizar();
  verificarColisaoEspinho();
  verificarToqueBandeira();
  desenhar();
  requestAnimationFrame(loopJogo);
}
function ContagemTempo() {
  if (tempoIniciado) return;
  tempoIniciado = true;
  intervaloTempo = setInterval(() => {
    if (!gameOver) {
      tempo--;
      if (tempo <= 0) {
        gameOver = true;
        alert("acabou o Tempo");
        location.reload();
      }
    }
    document.getElementById("tempoTela").textContent = `Tempo: ${tempo}s`;
  }, 1000);
}
loopJogo();
